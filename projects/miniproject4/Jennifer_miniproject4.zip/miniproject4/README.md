![preview](mini4.png)

This extension randomizes each letter within a paragraph tag's font size. When the user hovers over the letters, their font sizes are randomized again with different colors.
